# trends-proxy-vercel (개인용/무료 범위)

이 프로젝트는 Vercel에서 `/api/trends` 엔드포인트를 제공하는 아주 작은 프록시입니다.

## 왜 프록시가 필요?
브라우저는 CORS 정책 때문에 Google Trends / Naver DataLab 같은 소스를 직접 fetch 하기 어려운 경우가 많습니다.
또한 API 키를 프론트에 넣으면 유출 위험이 큽니다.
그래서 프록시가 대신 호출해 JSON으로 반환합니다.

## 배포 (Vercel)
1) 이 폴더를 깃허브에 올립니다
2) Vercel → Add New → Project → Import Git Repository → Deploy
3) 배포 후 주소 예: https://my-trends-proxy.vercel.app

## 테스트
브라우저에서 아래를 열면 JSON이 나옵니다.
- https://YOUR-VERCEL-DOMAIN/api/trends?source=mock&timeframe=hour&country=KR&lang=ko&cat=all
- https://YOUR-VERCEL-DOMAIN/api/trends?source=hackernews&timeframe=hour&country=KR&lang=ko&cat=all

## (선택) YouTube 키를 서버에 넣기
Vercel 프로젝트 → Settings → Environment Variables 에서
- Key: YT_KEY
- Value: (YouTube Data API Key)
추가 후 Redeploy

## 대시보드(HTML)에서 프록시 연결
대시보드 우측 상단 설정 → Proxy Base URL에 아래처럼 입력
- https://YOUR-VERCEL-DOMAIN
